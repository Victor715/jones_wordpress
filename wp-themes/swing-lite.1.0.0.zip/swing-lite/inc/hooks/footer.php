<?php
/**
 * Footer Section Function Area
*/

/**
 * Footer Before Function Area
**/



if ( ! function_exists( 'swing_lite_footer_before_cb' ) ) { 

	function swing_lite_footer_before_cb() { 
		$background_image = get_theme_mod('swing_lite_footer_background_image', '');
		?>
			<footer id="swing-footer" class="site-footer footer-wrapper">
				<?php if($background_image) { ?>
					<div class="overlay"></div>
				<?php } ?>
				<div class="s-container clear">
		<?php
	}
}
add_action( 'swing_lite_footer_before', 'swing_lite_footer_before_cb', 10 );


/**
 * Footer Widget area function area
**/
if ( ! function_exists( 'swing_lite_footer_contents_cb' ) ) {
	function swing_lite_footer_contents_cb() {

		$footer_top_text = get_theme_mod('swing_lite_footer_top_text', esc_html__( '2018 Hotel WordPress Theme is proudly powered by AccessPress Themess.', 'swing-lite' ) );
		$footer_bottom_text = get_theme_mod('swing_lite_footer_bottom_text', '');
		?>
		<div class="footer-container">

			<div class="footer-content footer-text">
				<?php echo wp_kses_post($footer_top_text);?>
			</div>

			<div class="footer-content">
				<?php echo do_shortcode($footer_bottom_text); ?>
			</div>

		</div>

	<?php 
       }  
		
}
add_action( 'swing_lite_footer_contents', 'swing_lite_footer_contents_cb', 20 );


/**
 * Footer After Function Area
**/
if ( ! function_exists( 'swing_lite_footer_after_cb' ) ) { 
	
	function swing_lite_footer_after_cb() { ?>
			</div> <!-- end of the ak-container -->
		</footer><!-- #colophon -->
		<?php
	}
}
add_action( 'swing_lite_footer_after', 'swing_lite_footer_after_cb', 40 );