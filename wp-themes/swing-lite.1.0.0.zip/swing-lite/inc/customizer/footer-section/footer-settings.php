<?php
/**
 * Load header panel file
*/
require $swing_lite_customizer_footer_options_file_path = swing_lite_file_directory('inc/customizer/footer-section/footer-options.php');